from .AccountAdmin import AccountAdmin;
from .CustomerAdmin import CustomerAdmin;
from .LoanAdmin import LoanAdmin;
from .AppointmentAdmin import AppointmentAdmin;